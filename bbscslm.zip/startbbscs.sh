java -Djava.awt.headless=true -jar start.jar etc/bbscs8.xml
