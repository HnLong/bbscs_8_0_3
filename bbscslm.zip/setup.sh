java -jar start.jar etc/setup.xml
